"""
SAM CLI version
"""

__version__ = "1.50.0"
